gotcp
================

A Go package for quickly building tcp servers


Usage
================

### Install

~~~
go get github.com/gansidui/gotcp
~~~


### Examples

* [echo](https://github.com/gansidui/gotcp/tree/master/examples/echo)
* [telnet](https://github.com/gansidui/gotcp/tree/master/examples/telnet)

Document
================

[Doc](http://godoc.org/github.com/gansidui/gotcp)